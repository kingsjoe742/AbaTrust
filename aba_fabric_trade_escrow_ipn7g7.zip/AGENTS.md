# Aba Fabric Escrow

> Built with Arc Studio - money-powered apps in minutes

Project memory for future agents and humans.

## What This App Does

USDC escrow plus onchain reputation for Aba fabric traders. Seller creates a deal, buyer locks USDC in escrow, buyer confirms delivery (or the inspection window lapses) and funds release to the seller. Completed deals update both parties' public reputation.

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS (Arc Light tokens in `src/index.css`)
- Web3: wagmi v2, viem v2, ConnectKit
- Contracts: Solidity 0.8.28 + Foundry. `contracts/FabricEscrow.sol`. Build `bun run contracts:build`, test `bun run contracts:test`.
- Chain: Arc Testnet (5042002). Token: USDC `0x3600000000000000000000000000000000000000` (6 decimals, ERC-20 view).

## Key Files

- `contracts/FabricEscrow.sol` - escrow + reputation contract (constructor: usdc, owner)
- `src/abi/fabricEscrow.ts` - ABI generated from the Foundry artifact; regenerate after any contract change
- `src/lib/escrow.ts` - constants, types, formatters. Contract address comes from `VITE_ESCROW_ADDRESS` in `.env`
- `src/hooks/useEscrowTx.ts` - single wrapper for wallet txs (chain switch, receipt wait, toasts, refetch)
- `src/components/` - DealsPanel, DealCard, DealActions, CreateDealSheet, WalletCard, ReputationCard, TraderLookup

## Contract design decisions

- Seller-facing statuses: Open, Funded, Delivered, Completed, Disputed, Refunded, Cancelled, Split.
- Payouts try a direct USDC transfer and fall back to a withdrawable `claimable` balance if the recipient is blocked.
- Reputation score counts only the first 3 completed deals per trading pair (wash-trading mitigation, partial).
- Disputes: arbiter or owner rules; after 14 days anyone can split the escrow 50/50 with no reputation change.
- Fee is 0% by default, owner-settable up to 2%, taken from the seller's proceeds.

## Deployment

- Deployed on Arc Testnet at 0x8668b5d1ea63a17cc7061238be1486385eb84c7a (owner and arbiter: platform deployer wallet, fee 0%). `VITE_ESCROW_ADDRESS` in `.env` points the app at it; restart the dev server after changing it.

## Share links

- Starter apps already ship `getShareBase`, `buildShareLink` and `installShareSync` in `src/lib/share.ts`; import them instead of rewriting them.
- Keep the `installShareSync()` call in `src/main.tsx` when editing it.
- Never put a secret in a URL path or query.
