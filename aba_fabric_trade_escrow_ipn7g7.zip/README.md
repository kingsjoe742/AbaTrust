# Aba Fabric Escrow

A USDC escrow and public reputation system for fabric traders in Aba. Sellers list a deal, buyers lock USDC in escrow, and funds release to the seller once delivery is confirmed. Every completed deal updates both traders' public reputation. All payments settle in USDC on Arc.

Built with [Arc Studio](https://studio.arc.io)

## Features

- Sellers create deals with fabric type, quantity, total price in USDC, delivery terms, a delivery date and an inspection window.
- Buyers lock the exact price in escrow, and the seller marks the order delivered with an optional photo or tracking link.
- Buyers confirm delivery (with an optional inspection photo or note) to release the funds. If a buyer stays silent past the inspection window, the seller can release the funds.
- If the seller never delivers, the buyer can claim a full refund after the delivery window.
- Buyers can dispute a deal. An arbiter rules on it, and an unresolved dispute can be split 50/50 after 14 days.
- Sellers can attach a fabric photo when listing a deal. It is stored on IPFS and shown on the deal card.
- Each trader has a public reputation score and trading stats that anyone can look up by wallet address.

## Tech stack

- React, Vite, TypeScript, Tailwind CSS
- wagmi, viem, ConnectKit
- Solidity 0.8.28 and Foundry (contract in `contracts/FabricEscrow.sol`)
- Arc Testnet, USDC

## Development

Prerequisites: [Bun](https://bun.sh) and [Foundry](https://book.getfoundry.sh).

```bash
bun install
bun run dev
```

Other commands:

```bash
bun run contracts:build   # compile the contract
bun run contracts:test    # run contract tests
bun run check             # lint and typecheck
```

### Environment variables

- `VITE_ESCROW_ADDRESS`: address of the deployed `FabricEscrow` contract on Arc Testnet. Without it the app shows a "not deployed" screen.
- `VITE_PINATA_JWT`: optional [Pinata](https://pinata.cloud) API key (JWT) used to upload deal photos to IPFS. Create a key limited to file uploads. It is bundled into the browser app, so use a restricted key. Without it, the photo picker is disabled.
