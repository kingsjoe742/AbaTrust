const PINATA_JWT = import.meta.env.VITE_PINATA_JWT as string | undefined

/** True when a Pinata key has been added to .env. */
export const UPLOADS_ENABLED = !!PINATA_JWT && PINATA_JWT.trim().length > 0

export const MAX_PHOTO_BYTES = 8 * 1024 * 1024

const GATEWAY = 'https://ipfs.io/ipfs/'
const CID_PATTERN = /^[A-Za-z0-9]{40,100}$/

export const ipfsUrl = (cid: string): string => `${GATEWAY}${cid}`

/** The photo link is appended to the delivery terms so the deal keeps it onchain. */
export const photoSuffix = (cid: string): string => `\nPhoto: ipfs://${cid}`

/** Splits stored delivery terms into readable text and an optional photo CID. */
export function splitTerms(terms: string): { text: string; cid?: string } {
  const match = /\n?Photo: ipfs:\/\/([A-Za-z0-9]+)\s*$/.exec(terms)
  if (!match || !CID_PATTERN.test(match[1])) return { text: terms }
  return { text: terms.slice(0, match.index).trim(), cid: match[1] }
}

/** Uploads an image to IPFS through Pinata and returns its CID. */
export async function uploadPhoto(file: File): Promise<string> {
  if (!UPLOADS_ENABLED) throw new Error('Photo uploads are not configured.')
  if (!file.type.startsWith('image/')) throw new Error('Choose an image file.')
  if (file.size > MAX_PHOTO_BYTES) throw new Error('Photo must be under 8 MB.')

  const body = new FormData()
  body.append('file', file)
  body.append('pinataMetadata', JSON.stringify({ name: `fabric-${Date.now()}` }))

  const res = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
    method: 'POST',
    headers: { Authorization: `Bearer ${PINATA_JWT}` },
    body,
  })
  if (res.status === 401 || res.status === 403) {
    throw new Error('Pinata rejected the key. Check VITE_PINATA_JWT in .env.')
  }
  if (!res.ok) throw new Error('Photo upload failed. Please try again.')

  const json = (await res.json()) as { IpfsHash?: string }
  if (!json.IpfsHash || !CID_PATTERN.test(json.IpfsHash)) throw new Error('Unexpected upload response.')
  return json.IpfsHash
}
