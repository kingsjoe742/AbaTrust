import { arcTestnet } from 'viem/chains'
import { isAddress, zeroAddress, type Address, type ReadContractReturnType } from 'viem'
import { fabricEscrowAbi } from '@/abi/fabricEscrow'
import { getUsdc } from '@/onchain-facts'
import { formatUnitsFixed, parseUsdc, usdcDecimalsFor } from '@/onchain-money'

export const CHAIN_ID = arcTestnet.id

const rawEscrow = import.meta.env.VITE_ESCROW_ADDRESS as string | undefined
/** Deployed FabricEscrow address, or undefined until the contract is deployed. */
export const ESCROW_ADDRESS: Address | undefined =
  rawEscrow && isAddress(rawEscrow) ? rawEscrow : undefined

const usdcFact = getUsdc(CHAIN_ID)
if (!usdcFact) throw new Error('USDC is not registered for Arc Testnet')
export const USDC_ADDRESS = usdcFact.address as Address

/** Spread into every wagmi read/write call. */
export const ESCROW = {
  address: ESCROW_ADDRESS ?? zeroAddress,
  abi: fabricEscrowAbi,
  chainId: CHAIN_ID,
} as const

export type Deal = ReadContractReturnType<typeof fabricEscrowAbi, 'getDeal'>
export type Reputation = ReadContractReturnType<typeof fabricEscrowAbi, 'reputationOf'>[0]

export const Status = {
  Open: 0,
  Funded: 1,
  Delivered: 2,
  Completed: 3,
  Disputed: 4,
  Refunded: 5,
  Cancelled: 6,
  Split: 7,
} as const

export const STATUS_LABEL: Record<number, string> = {
  0: 'Open',
  1: 'In escrow',
  2: 'Delivered',
  3: 'Completed',
  4: 'In dispute',
  5: 'Refunded',
  6: 'Cancelled',
  7: 'Split',
}

export type Tone = 'neutral' | 'info' | 'good' | 'warn' | 'bad'

export const STATUS_TONE: Record<number, Tone> = {
  0: 'info',
  1: 'warn',
  2: 'warn',
  3: 'good',
  4: 'bad',
  5: 'neutral',
  6: 'neutral',
  7: 'neutral',
}

// Mirrors the public constants of the deployed FabricEscrow contract.
export const GRACE_SECONDS = 2 * 86_400
export const DISPUTE_TIMEOUT_SECONDS = 14 * 86_400
export const MIN_PRICE_USDC = '1'

const decimals = usdcDecimalsFor(CHAIN_ID)

export const fmtUsdc = (raw: bigint): string => formatUnitsFixed(raw, decimals, 2)

export function parseUsdcInput(value: string): bigint | null {
  if (!value || !/^\d*\.?\d*$/.test(value) || value === '.') return null
  try {
    return parseUsdc(value)
  } catch {
    return null
  }
}

export const shortAddr = (addr: string): string => `${addr.slice(0, 6)}...${addr.slice(-4)}`

export const sameAddr = (a?: string, b?: string): boolean =>
  !!a && !!b && a.toLowerCase() === b.toLowerCase()

export const fmtDate = (ts: bigint | number): string =>
  new Date(Number(ts) * 1000).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })

export function fmtRemaining(seconds: number): string {
  if (seconds <= 0) return 'now'
  const d = Math.floor(seconds / 86_400)
  const h = Math.floor((seconds % 86_400) / 3_600)
  const m = Math.floor((seconds % 3_600) / 60)
  if (d > 0) return `${d}d ${h}h`
  if (h > 0) return `${h}h ${m}m`
  return `${Math.max(m, 1)}m`
}

export const byteLength = (s: string): number => new TextEncoder().encode(s).length

const FRIENDLY_ERRORS: Record<string, string> = {
  Unauthorized: 'This wallet is not allowed to do that on this deal.',
  InvalidStatus: 'The deal is no longer in the right state for this action.',
  SelfDeal: 'You cannot trade with yourself.',
  FundingClosed: 'The delivery deadline has passed, so this deal can no longer be funded.',
  DeliveryWindowClosed: 'The delivery window has closed. The buyer can now claim a refund.',
  WaitingPeriodActive: 'The waiting period is not over yet.',
  InspectionWindowClosed: 'The inspection window has ended, so a dispute can no longer be raised.',
  PriceTooLow: 'The price must be at least 1 USDC.',
  InvalidDeadline: 'The delivery deadline must be in the future.',
  InvalidInspectionWindow: 'The inspection window must be between 1 and 14 days.',
  InvalidAmount: 'Quantity must be greater than zero.',
  StringTooLong: 'One of the text fields is too long.',
}

export function friendlyErrorName(name?: string): string | undefined {
  return name ? FRIENDLY_ERRORS[name] : undefined
}
