import { useMemo } from 'react'
import { useReadContract } from 'wagmi'
import { ESCROW, type Deal } from '@/lib/escrow'

const PAGE = 50n

/** Latest deals (newest first), polled from the escrow contract. */
export function useDeals() {
  const count = useReadContract({
    ...ESCROW,
    functionName: 'dealCount',
    query: { refetchInterval: 10_000 },
  })
  const total = count.data ?? 0n
  const offset = total > PAGE ? total - PAGE : 0n

  const page = useReadContract({
    ...ESCROW,
    functionName: 'getDeals',
    args: [offset, PAGE],
    query: { enabled: count.data !== undefined, refetchInterval: 10_000 },
  })

  const deals = useMemo<Deal[]>(
    () => [...(page.data ?? [])].sort((a, b) => (a.id < b.id ? 1 : -1)),
    [page.data],
  )

  return {
    deals,
    total,
    isLoading: count.isLoading || (count.data !== undefined && page.isLoading),
    isError: count.isError || page.isError,
  }
}
