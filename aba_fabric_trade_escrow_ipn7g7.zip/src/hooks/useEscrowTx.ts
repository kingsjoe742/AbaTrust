import { useCallback, useState } from 'react'
import { useAccount, usePublicClient, useSwitchChain, useWriteContract } from 'wagmi'
import { useQueryClient } from '@tanstack/react-query'
import { BaseError, ContractFunctionRevertedError, type Hash } from 'viem'
import { toast } from 'sonner'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { CHAIN_ID, friendlyErrorName } from '@/lib/escrow'

function describeError(error: unknown): string | null {
  if (error instanceof BaseError) {
    const message = error.message.toLowerCase()
    if (message.includes('user rejected') || message.includes('user denied')) return null
    const reverted = error.walk((e) => e instanceof ContractFunctionRevertedError)
    if (reverted instanceof ContractFunctionRevertedError) {
      const friendly = friendlyErrorName(reverted.data?.errorName)
      if (friendly) return friendly
      if (reverted.data?.errorName) return `Transaction failed: ${reverted.data.errorName}`
    }
    if (message.includes('insufficient funds')) return 'Not enough USDC to cover gas. Use Get test USDC in the sidebar.'
    return error.shortMessage
  }
  return 'Something went wrong. Please try again.'
}

/** Runs one wallet transaction with chain switching, receipt waiting, toasts and cache refresh. */
export function useEscrowTx() {
  const { chainId } = useAccount()
  const { switchChainAsync } = useSwitchChain()
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient({ chainId: CHAIN_ID })
  const queryClient = useQueryClient()
  const [busyKey, setBusyKey] = useState<string | null>(null)

  const run = useCallback(
    async (key: string, successMessage: string, send: () => Promise<Hash>): Promise<boolean> => {
      if (!publicClient) return false
      setBusyKey(key)
      const toastId = toast.loading('Confirm in your wallet')
      try {
        if (chainId !== CHAIN_ID) await switchChainAsync({ chainId: CHAIN_ID })
        const hash = await send()
        toast.loading('Confirming on Arc', { id: toastId })
        const receipt = await publicClient.waitForTransactionReceipt({ hash })
        if (receipt.status !== 'success') throw new Error('Transaction reverted')
        toast.success(successMessage, {
          id: toastId,
          action: {
            label: 'View',
            onClick: () => window.open(buildTxExplorerUrl(CHAIN_ID, hash), '_blank', 'noopener,noreferrer'),
          },
        })
        await queryClient.invalidateQueries()
        return true
      } catch (error) {
        const message = describeError(error)
        if (message) toast.error(message, { id: toastId })
        else toast.dismiss(toastId)
        return false
      } finally {
        setBusyKey(null)
      }
    },
    [chainId, publicClient, queryClient, switchChainAsync],
  )

  return { run, write: writeContractAsync, busyKey, busy: busyKey !== null }
}
