import { ConnectKitButton } from 'connectkit'
import { Lock, PackageCheck, ShieldCheck, Store } from 'lucide-react'
import { ESCROW_ADDRESS } from '@/lib/escrow'
import { DealsPanel } from '@/components/DealsPanel'
import { WalletCard } from '@/components/WalletCard'
import { TraderLookup } from '@/components/TraderLookup'

const STEPS = [
  { icon: Store, title: 'List', body: 'Seller posts fabric, quantity, price and delivery terms.' },
  { icon: Lock, title: 'Lock', body: 'Buyer locks the USDC in escrow.' },
  { icon: PackageCheck, title: 'Deliver', body: 'Goods change hands. Buyer confirms after inspection.' },
  { icon: ShieldCheck, title: 'Earn trust', body: 'Funds release and both reputations grow.' },
]

function NotDeployed() {
  return (
    <div className="card mx-auto max-w-md p-8 text-center">
      <h2 className="display text-2xl font-bold">Escrow contract not deployed yet</h2>
      <p className="mt-2 text-sm text-pretty" style={{ color: 'var(--muted)' }}>
        The app is ready, but it needs a deployed escrow contract on Arc Testnet before deals can be created.
      </p>
    </div>
  )
}

export default function App() {
  return (
    <div className="min-h-dvh">
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-5">
        <div>
          <div className="label">Aba fabric trade</div>
          <h1 className="display text-2xl font-bold sm:text-3xl">Fabric Escrow</h1>
        </div>
        <ConnectKitButton />
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24">
        <ol className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {STEPS.map(({ icon: Icon, title, body }, i) => (
            <li key={title} className="inner p-4">
              <div className="flex items-center gap-2">
                <span
                  className="flex size-7 items-center justify-center rounded-lg"
                  style={{ background: 'rgba(18,45,69,0.08)' }}
                >
                  <Icon className="size-4" />
                </span>
                <span className="text-sm font-semibold">
                  {i + 1}. {title}
                </span>
              </div>
              <p className="mt-2 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
                {body}
              </p>
            </li>
          ))}
        </ol>

        {ESCROW_ADDRESS ? (
          <div className="grid gap-6 lg:grid-cols-[1fr_380px] lg:items-start">
            <DealsPanel />
            <aside className="space-y-4 lg:sticky lg:top-6">
              <WalletCard />
              <TraderLookup />
            </aside>
          </div>
        ) : (
          <NotDeployed />
        )}
      </main>
    </div>
  )
}
