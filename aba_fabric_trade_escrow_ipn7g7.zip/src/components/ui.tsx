import { useEffect, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Loader2, X } from 'lucide-react'
import { STATUS_LABEL, STATUS_TONE, type Tone } from '@/lib/escrow'

const TONES: Record<Tone, { bg: string; fg: string }> = {
  neutral: { bg: 'rgba(18,45,69,0.07)', fg: '#4a5b6c' },
  info: { bg: 'rgba(16,97,166,0.10)', fg: '#1061a6' },
  good: { bg: 'rgba(26,128,71,0.12)', fg: '#1a8047' },
  warn: { bg: 'rgba(154,98,0,0.12)', fg: '#8a5700' },
  bad: { bg: 'rgba(186,43,76,0.11)', fg: '#ba2b4c' },
}

export function Pill({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  const t = TONES[tone]
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold"
      style={{ background: t.bg, color: t.fg }}
    >
      {children}
    </span>
  )
}

export function StatusPill({ status }: { status: number }) {
  return <Pill tone={STATUS_TONE[status] ?? 'neutral'}>{STATUS_LABEL[status] ?? 'Unknown'}</Pill>
}

export function Spinner() {
  return <Loader2 className="size-4 animate-spin" aria-hidden />
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string
  hint?: string
  children: ReactNode
}) {
  return (
    <label className="block">
      <span className="label mb-1.5 block">{label}</span>
      {children}
      {hint && (
        <span className="mt-1 block text-xs" style={{ color: 'var(--subtle)' }}>
          {hint}
        </span>
      )}
    </label>
  )
}

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center sm:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" />
          <motion.section
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className="relative max-h-[92dvh] w-full max-w-md overflow-y-auto rounded-t-3xl sm:rounded-3xl"
            style={{
              background: 'rgba(255,255,255,0.94)',
              backdropFilter: 'blur(40px) saturate(200%)',
              WebkitBackdropFilter: 'blur(40px) saturate(200%)',
            }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 36 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center pt-3 sm:hidden">
              <div className="h-1 w-10 rounded-full bg-black/10" />
            </div>
            <div className="flex items-center justify-between px-5 pb-2 pt-3">
              <h2 className="display text-xl font-bold">{title}</h2>
              <button
                onClick={onClose}
                aria-label="Close"
                className="flex size-10 items-center justify-center rounded-full hover:bg-black/5"
              >
                <X className="size-5" />
              </button>
            </div>
            <div className="px-5 pb-6">{children}</div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
