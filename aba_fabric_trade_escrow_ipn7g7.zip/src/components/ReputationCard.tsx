import { useReadContract } from 'wagmi'
import { ShieldCheck } from 'lucide-react'
import type { Address } from 'viem'
import { ESCROW, fmtUsdc, shortAddr } from '@/lib/escrow'
import { Pill } from './ui'

export function tierFor(score: number): { label: string; tone: 'neutral' | 'info' | 'good' } {
  if (score >= 150) return { label: 'Trusted trader', tone: 'good' }
  if (score >= 50) return { label: 'Established', tone: 'info' }
  return { label: score > 0 ? 'Building history' : 'New trader', tone: 'neutral' }
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'bad' }) {
  return (
    <div className="inner p-3">
      <div className="label">{label}</div>
      <div
        className="display mt-1 text-lg font-bold tabular-nums"
        style={{ color: tone === 'bad' && value !== '0' ? 'var(--danger)' : 'var(--ink)' }}
      >
        {value}
      </div>
    </div>
  )
}

/** Public onchain reputation for any address. */
export function ReputationCard({ address, title }: { address: Address; title?: string }) {
  const { data, isLoading, isError } = useReadContract({
    ...ESCROW,
    functionName: 'reputationOf',
    args: [address],
    query: { refetchInterval: 15_000 },
  })

  const rep = data?.[0]
  const score = data ? Number(data[1]) : 0
  const tier = tierFor(score)

  return (
    <section className="card p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="size-4" style={{ color: 'var(--success)' }} />
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            {title ?? 'Reputation'}
          </span>
        </div>
        <span className="mono text-xs" style={{ color: 'var(--subtle)' }}>
          {shortAddr(address)}
        </span>
      </div>

      <div className="mt-3 flex items-end justify-between gap-3">
        <div className="flex items-baseline gap-1.5">
          <span className="display text-5xl font-bold tabular-nums">
            {isLoading ? '...' : isError ? '--' : score}
          </span>
          <span className="text-sm font-medium" style={{ color: 'var(--subtle)' }}>
            points
          </span>
        </div>
        <Pill tone={tier.tone}>{tier.label}</Pill>
      </div>

      {rep && (
        <>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Stat label="Deals completed" value={String(rep.completedDeals)} />
            <Stat label="Trading partners" value={String(rep.uniqueCounterparties)} />
            <Stat label="Volume (USDC)" value={fmtUsdc(rep.volume)} />
            <Stat
              label="Disputes lost"
              value={String(rep.disputesLost + rep.nonDeliveries)}
              tone="bad"
            />
          </div>
          <p className="mt-3 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
            {rep.completedAsSeller} as seller, {rep.completedAsBuyer} as buyer. The score counts the first 3 deals with
            each trading partner, so repeat deals between the same two wallets cannot inflate it.
          </p>
        </>
      )}
    </section>
  )
}
