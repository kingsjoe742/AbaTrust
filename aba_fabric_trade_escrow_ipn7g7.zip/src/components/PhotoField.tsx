import { useRef, useState } from 'react'
import { ImagePlus, X } from 'lucide-react'
import { UPLOADS_ENABLED, ipfsUrl, uploadPhoto } from '@/lib/ipfs'
import { Spinner } from './ui'

/** Lets a seller attach a fabric photo; the file is pinned to IPFS and the CID is reported upward. */
export function PhotoField({
  cid,
  onChange,
  onBusyChange,
}: {
  cid: string | null
  onChange: (cid: string | null) => void
  onBusyChange: (busy: boolean) => void
}) {
  const input = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(null)

  const pick = async (file: File | undefined) => {
    if (!file) return
    setError(null)
    setUploading(true)
    onBusyChange(true)
    try {
      const hash = await uploadPhoto(file)
      setPreview((old) => {
        if (old) URL.revokeObjectURL(old)
        return URL.createObjectURL(file)
      })
      onChange(hash)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Photo upload failed.')
    } finally {
      setUploading(false)
      onBusyChange(false)
      if (input.current) input.current.value = ''
    }
  }

  const remove = () => {
    if (preview) URL.revokeObjectURL(preview)
    setPreview(null)
    onChange(null)
  }

  return (
    <div>
      <span className="label mb-1.5 block">Fabric photo (optional)</span>

      {cid ? (
        <div className="inner flex items-center gap-3 p-2.5">
          <img
            src={preview ?? ipfsUrl(cid)}
            alt="Fabric preview"
            className="size-16 rounded-xl object-cover"
          />
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold" style={{ color: 'var(--success)' }}>
              Uploaded to IPFS
            </div>
            <div className="mono truncate text-[11px]" style={{ color: 'var(--subtle)' }}>
              {cid}
            </div>
          </div>
          <button
            type="button"
            onClick={remove}
            aria-label="Remove photo"
            className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-black/5"
          >
            <X className="size-4" />
          </button>
        </div>
      ) : (
        <button
          type="button"
          disabled={!UPLOADS_ENABLED || uploading}
          onClick={() => input.current?.click()}
          className="flex min-h-24 w-full flex-col items-center justify-center gap-1.5 rounded-2xl border border-dashed p-4 text-sm transition-colors hover:bg-black/[0.02] disabled:cursor-not-allowed disabled:opacity-60"
          style={{ borderColor: 'var(--border-strong)', color: 'var(--ink-2)' }}
        >
          {uploading ? (
            <>
              <Spinner />
              <span>Uploading to IPFS</span>
            </>
          ) : (
            <>
              <ImagePlus className="size-5" />
              <span className="font-semibold">Add a photo</span>
              <span className="text-xs" style={{ color: 'var(--subtle)' }}>
                JPG or PNG, up to 8 MB
              </span>
            </>
          )}
        </button>
      )}

      <input
        ref={input}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => void pick(e.target.files?.[0])}
      />

      {!UPLOADS_ENABLED && (
        <p className="mt-1.5 text-xs text-pretty" style={{ color: 'var(--muted)' }}>
          Photo uploads need a Pinata key. Add VITE_PINATA_JWT to your .env file and restart the app.
        </p>
      )}
      {error && (
        <p className="mt-1.5 text-xs" style={{ color: 'var(--danger)' }}>
          {error}
        </p>
      )}
    </div>
  )
}
