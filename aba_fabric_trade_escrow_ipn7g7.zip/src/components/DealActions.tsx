import { useState, type ReactNode } from 'react'
import { useReadContract } from 'wagmi'
import { erc20Abi, zeroAddress, type Address } from 'viem'
import { CheckCircle2, Flag, PackageCheck, RotateCcw, Scale, Undo2, Wallet } from 'lucide-react'
import {
  CHAIN_ID,
  DISPUTE_TIMEOUT_SECONDS,
  ESCROW,
  GRACE_SECONDS,
  Status,
  USDC_ADDRESS,
  byteLength,
  fmtRemaining,
  fmtUsdc,
  sameAddr,
  type Deal,
} from '@/lib/escrow'
import { useEscrowTx } from '@/hooks/useEscrowTx'
import { Spinner } from './ui'

type Mode = 'deliver' | 'confirm' | 'dispute' | null

const FORM_COPY = {
  deliver: {
    label: 'Delivery photo or tracking link (optional)',
    placeholder: 'https://... or ipfs://...',
    cta: 'Mark as delivered',
  },
  confirm: {
    label: 'Inspection photo or note link (optional)',
    placeholder: 'https://... or ipfs://...',
    cta: 'Release funds to seller',
  },
  dispute: {
    label: 'Reason or evidence link',
    placeholder: 'Describe the problem or link to photos',
    cta: 'Raise dispute',
  },
} as const

function ActionButton({
  name,
  dealId,
  busyKey,
  busy,
  onClick,
  icon,
  children,
  variant = 'btn-primary',
}: {
  name: string
  dealId: bigint
  busyKey: string | null
  busy: boolean
  onClick: () => unknown
  icon: ReactNode
  children: ReactNode
  variant?: string
}) {
  return (
    <button className={`btn btn-sm ${variant}`} disabled={busy} onClick={() => void onClick()}>
      {busyKey === `${name}-${dealId}` ? <Spinner /> : icon}
      {children}
    </button>
  )
}

export function DealActions({ deal: d, me, now }: { deal: Deal; me?: Address; now: number }) {
  const { run, write, busyKey, busy } = useEscrowTx()
  const [mode, setMode] = useState<Mode>(null)
  const [text, setText] = useState('')

  const status = d.status
  const isSeller = sameAddr(d.seller, me)
  const isBuyer = sameAddr(d.buyer, me)
  const deadline = Number(d.deliveryDeadline)
  const graceEnd = deadline + GRACE_SECONDS
  const windowEnd = Number(d.deliveredAt) + Number(d.inspectionWindow)
  const staleEnd = Number(d.disputedAt) + DISPUTE_TIMEOUT_SECONDS

  const canFund =
    status === Status.Open && !!me && !isSeller && (d.buyer === zeroAddress || isBuyer) && now < deadline

  const { data: allowance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    chainId: CHAIN_ID,
    functionName: 'allowance',
    args: me ? [me, ESCROW.address] : undefined,
    query: { enabled: canFund, refetchInterval: 8_000 },
  })

  const { data: arbiter } = useReadContract({
    ...ESCROW,
    functionName: 'arbiter',
    query: { enabled: status === Status.Disputed },
  })
  const { data: owner } = useReadContract({
    ...ESCROW,
    functionName: 'owner',
    query: { enabled: status === Status.Disputed },
  })
  const isResolver = sameAddr(arbiter, me) || sameAddr(owner, me)

  const key = (name: string) => `${name}-${d.id}`

  const submitForm = async () => {
    if (!mode) return
    let ok = false
    if (mode === 'deliver') {
      ok = await run(key('deliver'), 'Marked as delivered', () =>
        write({ ...ESCROW, functionName: 'markDelivered', args: [d.id, text.trim()] }),
      )
    } else if (mode === 'confirm') {
      ok = await run(key('confirm'), 'Funds released to the seller', () =>
        write({ ...ESCROW, functionName: 'confirmDelivery', args: [d.id, text.trim()] }),
      )
    } else {
      ok = await run(key('dispute'), 'Dispute raised', () =>
        write({ ...ESCROW, functionName: 'raiseDispute', args: [d.id, text.trim()] }),
      )
    }
    if (ok) {
      setMode(null)
      setText('')
    }
  }

  const open = (m: Mode) => {
    setText('')
    setMode(m)
  }

  const note = (msg: string) => (
    <p className="text-xs text-pretty" style={{ color: 'var(--muted)' }}>
      {msg}
    </p>
  )

  const tooLong = byteLength(text) > 256
  const needsReason = mode === 'dispute' && text.trim().length === 0

  // ---- form mode -------------------------------------------------------
  if (mode) {
    const copy = FORM_COPY[mode]
    return (
      <div className="space-y-3">
        <label className="block">
          <span className="label mb-1.5 block">{copy.label}</span>
          <input
            className="field"
            value={text}
            placeholder={copy.placeholder}
            onChange={(e) => setText(e.target.value)}
            autoFocus
          />
          {tooLong && (
            <span className="mt-1 block text-xs" style={{ color: 'var(--danger)' }}>
              Keep this under 256 characters.
            </span>
          )}
        </label>
        <div className="flex gap-2">
          <button
            className={`btn btn-sm flex-1 ${mode === 'dispute' ? 'btn-danger' : 'btn-primary'}`}
            disabled={busy || tooLong || needsReason}
            onClick={() => void submitForm()}
          >
            {busy ? <Spinner /> : null}
            {copy.cta}
          </button>
          <button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => setMode(null)}>
            Back
          </button>
        </div>
      </div>
    )
  }

  // ---- by status -------------------------------------------------------
  if (status === Status.Open) {
    return (
      <div className="space-y-2">
        {isSeller && (
          <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
            name="cancel"
            variant="btn-ghost"
            icon={<Undo2 className="size-4" />}
            onClick={() =>
              run(key('cancel'), 'Deal cancelled', () =>
                write({ ...ESCROW, functionName: 'cancelDeal', args: [d.id] }),
              )
            }
          >
            Cancel deal
          </ActionButton>
        )}
        {canFund && (allowance ?? 0n) < d.price && (
          <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
            name="approve"
            icon={<Wallet className="size-4" />}
            onClick={() =>
              run(key('approve'), `Allowed ${fmtUsdc(d.price)} USDC for this deal`, () =>
                write({
                  address: USDC_ADDRESS,
                  abi: erc20Abi,
                  chainId: CHAIN_ID,
                  functionName: 'approve',
                  args: [ESCROW.address, d.price],
                }),
              )
            }
          >
            Allow {fmtUsdc(d.price)} USDC
          </ActionButton>
        )}
        {canFund && (allowance ?? 0n) >= d.price && (
          <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
            name="fund"
            icon={<Wallet className="size-4" />}
            onClick={() =>
              run(key('fund'), 'USDC locked in escrow', () =>
                write({ ...ESCROW, functionName: 'fundDeal', args: [d.id] }),
              )
            }
          >
            Lock {fmtUsdc(d.price)} USDC in escrow
          </ActionButton>
        )}
        {!me && note('Connect a wallet to fund this deal.')}
        {me && !isSeller && !canFund && d.buyer !== zeroAddress && !isBuyer && note('Reserved for another buyer.')}
        {me && !isSeller && now >= deadline && note('The delivery deadline has passed, so this deal cannot be funded.')}
      </div>
    )
  }

  if (status === Status.Funded) {
    return (
      <div className="space-y-2">
        <div className="flex flex-wrap gap-2">
          {isSeller && now <= graceEnd && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id} name="deliver" icon={<PackageCheck className="size-4" />} onClick={() => open('deliver')}>
              Mark as delivered
            </ActionButton>
          )}
          {isBuyer && (
            <>
              <ActionButton busyKey={busyKey} busy={busy} dealId={d.id} name="confirm" icon={<CheckCircle2 className="size-4" />} onClick={() => open('confirm')}>
                Confirm delivery
              </ActionButton>
              <ActionButton busyKey={busyKey} busy={busy} dealId={d.id} name="dispute" variant="btn-danger" icon={<Flag className="size-4" />} onClick={() => open('dispute')}>
                Dispute
              </ActionButton>
            </>
          )}
          {isBuyer && now > graceEnd && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
              name="refund"
              variant="btn-ghost"
              icon={<RotateCcw className="size-4" />}
              onClick={() =>
                run(key('refund'), 'Refund sent to your wallet', () =>
                  write({ ...ESCROW, functionName: 'refundExpired', args: [d.id] }),
                )
              }
            >
              Claim refund
            </ActionButton>
          )}
        </div>
        {isSeller && note(
          now <= graceEnd
            ? `Funds are locked. Mark the order delivered within ${fmtRemaining(graceEnd - now)} to stay eligible for payment.`
            : 'The delivery window closed. The buyer can claim a refund.',
        )}
        {isBuyer && now <= graceEnd && note('Your USDC is locked until you confirm delivery, or until the seller misses the deadline.')}
        {!isSeller && !isBuyer && note('Waiting for the seller to deliver.')}
      </div>
    )
  }

  if (status === Status.Delivered) {
    const inWindow = now <= windowEnd
    return (
      <div className="space-y-2">
        <div className="flex flex-wrap gap-2">
          {isBuyer && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id} name="confirm" icon={<CheckCircle2 className="size-4" />} onClick={() => open('confirm')}>
              Confirm delivery
            </ActionButton>
          )}
          {isBuyer && inWindow && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id} name="dispute" variant="btn-danger" icon={<Flag className="size-4" />} onClick={() => open('dispute')}>
              Dispute
            </ActionButton>
          )}
          {!inWindow && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
              name="claim"
              icon={<CheckCircle2 className="size-4" />}
              onClick={() =>
                run(key('claim'), 'Funds released to the seller', () =>
                  write({ ...ESCROW, functionName: 'claimAfterInspectionWindow', args: [d.id] }),
                )
              }
            >
              Release funds to seller
            </ActionButton>
          )}
        </div>
        {inWindow
          ? note(`Inspection window closes in ${fmtRemaining(windowEnd - now)}. After that, the seller can release the funds.`)
          : note('The inspection window has ended with no dispute. Anyone can release the funds to the seller.')}
      </div>
    )
  }

  if (status === Status.Disputed) {
    return (
      <div className="space-y-2">
        <div className="flex flex-wrap gap-2">
          {isResolver && (
            <>
              <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
                name="to-seller"
                icon={<Scale className="size-4" />}
                onClick={() =>
                  run(key('to-seller'), 'Dispute resolved for the seller', () =>
                    write({ ...ESCROW, functionName: 'resolveDispute', args: [d.id, true] }),
                  )
                }
              >
                Pay seller
              </ActionButton>
              <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
                name="to-buyer"
                variant="btn-ghost"
                icon={<RotateCcw className="size-4" />}
                onClick={() =>
                  run(key('to-buyer'), 'Dispute resolved for the buyer', () =>
                    write({ ...ESCROW, functionName: 'resolveDispute', args: [d.id, false] }),
                  )
                }
              >
                Refund buyer
              </ActionButton>
            </>
          )}
          {now > staleEnd && (
            <ActionButton busyKey={busyKey} busy={busy} dealId={d.id}
              name="split"
              variant="btn-ghost"
              icon={<Scale className="size-4" />}
              onClick={() =>
                run(key('split'), 'Escrow split 50/50', () =>
                  write({ ...ESCROW, functionName: 'resolveStaleDispute', args: [d.id] }),
                )
              }
            >
              Split 50/50
            </ActionButton>
          )}
        </div>
        {note(
          now > staleEnd
            ? 'The arbiter did not rule in time. Anyone can now split the escrow evenly.'
            : `The arbiter is reviewing this dispute. If there is no ruling in ${fmtRemaining(staleEnd - now)}, the escrow can be split 50/50.`,
        )}
      </div>
    )
  }

  return null
}
