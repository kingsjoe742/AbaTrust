import { useState } from 'react'
import { isAddress, zeroAddress } from 'viem'
import { useAccount } from 'wagmi'
import { TokenUSDC } from '@web3icons/react'
import { ESCROW, MIN_PRICE_USDC, byteLength, parseUsdcInput, sameAddr } from '@/lib/escrow'
import { useEscrowTx } from '@/hooks/useEscrowTx'
import { useNow } from '@/hooks/useNow'
import { photoSuffix } from '@/lib/ipfs'
import { Field, Sheet, Spinner } from './ui'
import { PhotoField } from './PhotoField'

const UNITS = ['yards', 'meters', 'bales', 'pieces']
const WINDOWS = [1, 3, 7, 14]

const dateInput = (days: number) => {
  const d = new Date(Date.now() + days * 86_400_000)
  return d.toISOString().slice(0, 10)
}

export function CreateDealSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { address } = useAccount()
  const { run, write, busy } = useEscrowTx()
  const now = useNow()
  const [minDate] = useState(() => dateInput(1))

  const [fabric, setFabric] = useState('')
  const [quantity, setQuantity] = useState('')
  const [unit, setUnit] = useState(UNITS[0])
  const [price, setPrice] = useState('')
  const [terms, setTerms] = useState('')
  const [deadline, setDeadline] = useState(() => dateInput(14))
  const [windowDays, setWindowDays] = useState(3)
  const [buyer, setBuyer] = useState('')
  const [photoCid, setPhotoCid] = useState<string | null>(null)
  const [photoBusy, setPhotoBusy] = useState(false)

  const priceRaw = parseUsdcInput(price)
  const qty = /^\d+$/.test(quantity) ? BigInt(quantity) : 0n
  const deadlineTs = Math.floor(new Date(`${deadline}T23:59:59`).getTime() / 1000)
  const buyerTrim = buyer.trim()
  const buyerValid = buyerTrim === '' || (isAddress(buyerTrim) && !sameAddr(buyerTrim, address))

  const suffix = photoCid ? photoSuffix(photoCid) : ''
  const termsLimit = 512 - byteLength(suffix)
  const minRaw = parseUsdcInput(MIN_PRICE_USDC) ?? 0n
  const problems: string[] = []
  if (!fabric.trim()) problems.push('Enter the fabric type')
  else if (byteLength(fabric) > 64) problems.push('Fabric type is too long')
  if (qty === 0n) problems.push('Enter a whole-number quantity')
  if (priceRaw === null || priceRaw < minRaw) problems.push(`Price must be at least ${MIN_PRICE_USDC} USDC`)
  if (byteLength(terms.trim()) > termsLimit) problems.push('Delivery terms are too long')
  if (photoBusy) problems.push('Wait for the photo to finish uploading')
  if (!Number.isFinite(deadlineTs) || deadlineTs <= now) problems.push('Pick a future delivery date')
  if (!buyerValid) problems.push('Buyer must be a valid address other than yours')

  const reset = () => {
    setFabric('')
    setQuantity('')
    setPrice('')
    setTerms('')
    setBuyer('')
    setPhotoCid(null)
  }

  const submit = async () => {
    if (problems.length > 0 || priceRaw === null) return
    const ok = await run('create', 'Deal created', () =>
      write({
        ...ESCROW,
        functionName: 'createDeal',
        args: [
          fabric.trim(),
          qty,
          unit,
          priceRaw,
          terms.trim() + suffix,
          BigInt(deadlineTs),
          BigInt(windowDays * 86_400),
          buyerTrim === '' ? zeroAddress : (buyerTrim as `0x${string}`),
        ],
      }),
    )
    if (ok) {
      reset()
      onClose()
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="New fabric deal">
      <div className="space-y-4">
        <Field label="Fabric type">
          <input className="field" placeholder="e.g. Ankara wax print, Aso-oke" value={fabric} onChange={(e) => setFabric(e.target.value)} />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Quantity">
            <input className="field tabular-nums" inputMode="numeric" placeholder="100" value={quantity} onChange={(e) => setQuantity(e.target.value.replace(/\D/g, ''))} />
          </Field>
          <Field label="Unit">
            <select className="field" value={unit} onChange={(e) => setUnit(e.target.value)}>
              {UNITS.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </Field>
        </div>

        <div className="inner p-4">
          <span className="label">Total price</span>
          <div className="mt-1 flex items-center gap-2">
            <input
              className="display w-full bg-transparent text-4xl font-bold tabular-nums outline-none placeholder:text-slate-300"
              inputMode="decimal"
              placeholder="0.00"
              value={price}
              onChange={(e) => {
                const v = e.target.value.replace(/[^0-9.]/g, '')
                if (/^\d*\.?\d*$/.test(v)) setPrice(v)
              }}
              aria-label="Total price in USDC"
            />
            <span className="flex items-center gap-1 text-sm font-medium" style={{ color: 'var(--subtle)' }}>
              <TokenUSDC variant="branded" size={18} /> USDC
            </span>
          </div>
        </div>

        <Field label="Delivery terms" hint={`Where, how, and in what condition the fabric will be delivered. ${Math.max(termsLimit - byteLength(terms.trim()), 0)} characters left.`}>
          <textarea className="field min-h-20" rows={3} placeholder="Pickup at Ariaria Market, Aba. Rolls inspected before handover." value={terms} onChange={(e) => setTerms(e.target.value)} />
        </Field>

        <PhotoField cid={photoCid} onChange={setPhotoCid} onBusyChange={setPhotoBusy} />

        <div className="grid grid-cols-2 gap-3">
          <Field label="Deliver by">
            <input type="date" className="field" min={minDate} value={deadline} onChange={(e) => setDeadline(e.target.value)} />
          </Field>
          <Field label="Inspection window">
            <select className="field" value={windowDays} onChange={(e) => setWindowDays(Number(e.target.value))}>
              {WINDOWS.map((w) => (
                <option key={w} value={w}>
                  {w} {w === 1 ? 'day' : 'days'}
                </option>
              ))}
            </select>
          </Field>
        </div>

        <Field label="Reserve for a buyer (optional)" hint="Leave empty to let any buyer fund this deal.">
          <input className="field mono" placeholder="0x..." value={buyer} onChange={(e) => setBuyer(e.target.value)} />
        </Field>

        {problems.length > 0 && fabric + quantity + price !== '' && (
          <ul className="space-y-0.5 text-xs" style={{ color: 'var(--danger)' }}>
            {problems.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        )}

        <button className="btn btn-primary w-full" disabled={busy || problems.length > 0} onClick={() => void submit()}>
          {busy ? <Spinner /> : null}
          {busy ? 'Creating deal' : 'Create deal'}
        </button>
      </div>
    </Sheet>
  )
}
