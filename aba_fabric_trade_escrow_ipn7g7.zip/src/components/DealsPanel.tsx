import { useMemo, useState } from 'react'
import { useAccount } from 'wagmi'
import { Inbox, Plus } from 'lucide-react'
import { Status, sameAddr } from '@/lib/escrow'
import { useDeals } from '@/hooks/useDeals'
import { useNow } from '@/hooks/useNow'
import { DealCard } from './DealCard'
import { CreateDealSheet } from './CreateDealSheet'
import { Spinner } from './ui'

type Tab = 'market' | 'mine' | 'all'

const TABS: { id: Tab; label: string }[] = [
  { id: 'market', label: 'Marketplace' },
  { id: 'mine', label: 'My deals' },
  { id: 'all', label: 'All deals' },
]

export function DealsPanel() {
  const { address, isConnected } = useAccount()
  const { deals, total, isLoading, isError } = useDeals()
  const now = useNow()
  const [tab, setTab] = useState<Tab>('market')
  const [creating, setCreating] = useState(false)

  const visible = useMemo(() => {
    if (tab === 'market') {
      return deals.filter((d) => d.status === Status.Open && Number(d.deliveryDeadline) > now)
    }
    if (tab === 'mine') return deals.filter((d) => sameAddr(d.seller, address) || sameAddr(d.buyer, address))
    return deals
  }, [deals, tab, address, now])

  const emptyCopy =
    tab === 'market'
      ? 'No open deals right now. Create one to get started.'
      : tab === 'mine'
        ? isConnected
          ? 'You have no deals yet.'
          : 'Connect your wallet to see your deals.'
        : 'No deals have been created yet.'

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div
          role="tablist"
          className="inline-flex rounded-2xl p-1"
          style={{ background: 'var(--surface-muted)' }}
        >
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className="min-h-10 rounded-xl px-4 text-sm font-semibold transition-colors"
              style={{
                background: tab === t.id ? 'var(--surface-strong)' : 'transparent',
                color: tab === t.id ? 'var(--ink)' : 'var(--muted)',
                boxShadow: tab === t.id ? '0 1px 3px rgba(18,45,69,0.12)' : 'none',
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
        <button className="btn btn-primary" onClick={() => setCreating(true)} disabled={!isConnected}>
          <Plus className="size-4" />
          New deal
        </button>
      </div>

      {isLoading && (
        <div className="card flex items-center justify-center gap-2 p-10 text-sm" style={{ color: 'var(--muted)' }}>
          <Spinner /> Loading deals from Arc
        </div>
      )}

      {isError && (
        <div className="card p-6 text-sm" style={{ color: 'var(--danger)' }}>
          Could not load deals. Check your connection and try again.
        </div>
      )}

      {!isLoading && !isError && visible.length === 0 && (
        <div className="card flex flex-col items-center gap-2 p-10 text-center">
          <Inbox className="size-8" style={{ color: 'var(--subtle)' }} />
          <p className="text-sm text-pretty" style={{ color: 'var(--muted)' }}>
            {emptyCopy}
          </p>
        </div>
      )}

      <div className="space-y-4">
        {visible.map((d) => (
          <DealCard key={String(d.id)} deal={d} me={address} now={now} />
        ))}
      </div>

      {total > 50n && (
        <p className="text-center text-xs" style={{ color: 'var(--subtle)' }}>
          Showing the latest 50 of {String(total)} deals.
        </p>
      )}

      <CreateDealSheet open={creating} onClose={() => setCreating(false)} />
    </section>
  )
}
