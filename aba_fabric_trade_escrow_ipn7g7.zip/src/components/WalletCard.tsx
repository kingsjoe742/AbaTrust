import { useAccount, useReadContract } from 'wagmi'
import { erc20Abi } from 'viem'
import { ConnectKitButton } from 'connectkit'
import { Wallet } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { CHAIN_ID, ESCROW, USDC_ADDRESS, fmtUsdc } from '@/lib/escrow'
import { useEscrowTx } from '@/hooks/useEscrowTx'
import { ReputationCard } from './ReputationCard'
import { Spinner } from './ui'

export function WalletCard() {
  const { address, isConnected } = useAccount()
  const { run, write, busy } = useEscrowTx()

  const { data: balance, isLoading } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    chainId: CHAIN_ID,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: { enabled: !!address, refetchInterval: 8_000 },
  })

  const { data: claimable } = useReadContract({
    ...ESCROW,
    functionName: 'claimable',
    args: address ? [address] : undefined,
    query: { enabled: !!address, refetchInterval: 10_000 },
  })

  if (!isConnected || !address) {
    return (
      <section className="card p-5">
        <div className="flex items-center gap-1.5">
          <Wallet className="size-4" style={{ color: 'var(--muted)' }} />
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Your wallet
          </span>
        </div>
        <p className="mt-3 text-sm text-pretty" style={{ color: 'var(--ink-2)' }}>
          Connect a wallet on Arc Testnet to create deals, lock USDC, and build your onchain reputation.
        </p>
        <div className="mt-4">
          <ConnectKitButton.Custom>
            {({ show }) => (
              <button className="btn btn-primary w-full" onClick={show}>
                Connect wallet
              </button>
            )}
          </ConnectKitButton.Custom>
        </div>
      </section>
    )
  }

  return (
    <div className="space-y-4">
      <section className="card p-5">
        <div className="flex items-center gap-1.5">
          <Wallet className="size-4" style={{ color: 'var(--muted)' }} />
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            USDC balance
          </span>
        </div>
        <div className="mt-2 flex items-baseline gap-1.5">
          <span className="display text-4xl font-bold tabular-nums">
            {isLoading || balance === undefined ? '...' : fmtUsdc(balance)}
          </span>
          <TokenUSDC variant="branded" size={20} className="self-center" />
          <span className="text-lg font-medium" style={{ color: 'var(--subtle)' }}>
            USDC
          </span>
        </div>
        <p className="mt-1 text-xs" style={{ color: 'var(--muted)' }}>
          Arc Testnet. Gas is paid in USDC too.
        </p>

        {claimable !== undefined && claimable > 0n && (
          <div className="inner mt-4 flex items-center justify-between gap-3 p-3">
            <div>
              <div className="label">Ready to withdraw</div>
              <div className="display text-lg font-bold tabular-nums">{fmtUsdc(claimable)} USDC</div>
            </div>
            <button
              className="btn btn-sm btn-primary"
              disabled={busy}
              onClick={() =>
                void run('withdraw', 'USDC withdrawn', () =>
                  write({ ...ESCROW, functionName: 'withdraw', args: [address] }),
                )
              }
            >
              {busy ? <Spinner /> : null}
              Withdraw
            </button>
          </div>
        )}
      </section>

      <ReputationCard address={address} title="Your reputation" />
    </div>
  )
}
