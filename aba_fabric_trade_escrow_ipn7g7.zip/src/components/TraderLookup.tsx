import { useState } from 'react'
import { isAddress } from 'viem'
import { Search } from 'lucide-react'
import { ReputationCard } from './ReputationCard'

/** Look up the public reputation of any trader before dealing with them. */
export function TraderLookup() {
  const [query, setQuery] = useState('')
  const value = query.trim()
  const valid = isAddress(value)

  return (
    <section className="space-y-3">
      <div className="card p-5">
        <div className="flex items-center gap-1.5">
          <Search className="size-4" style={{ color: 'var(--muted)' }} />
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Check a trader
          </span>
        </div>
        <input
          className="field mono mt-3"
          placeholder="Paste a wallet address (0x...)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Trader wallet address"
        />
        {value !== '' && !valid && (
          <p className="mt-2 text-xs" style={{ color: 'var(--danger)' }}>
            That is not a valid address.
          </p>
        )}
      </div>
      {valid && <ReputationCard address={value} title="Trader reputation" />}
    </section>
  )
}
