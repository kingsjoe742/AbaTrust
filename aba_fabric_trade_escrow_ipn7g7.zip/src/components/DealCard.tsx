import { useReadContract } from 'wagmi'
import { zeroAddress, type Address } from 'viem'
import { CalendarClock, ExternalLink, ShieldCheck } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { buildAddressExplorerUrl } from '@/onchain-facts'
import { CHAIN_ID, ESCROW, Status, fmtDate, fmtUsdc, sameAddr, shortAddr, type Deal } from '@/lib/escrow'
import { DealActions } from './DealActions'
import { ipfsUrl, splitTerms } from '@/lib/ipfs'
import { Pill, StatusPill } from './ui'

function ScoreChip({ address }: { address: Address }) {
  const { data } = useReadContract({
    ...ESCROW,
    functionName: 'scoreOf',
    args: [address],
    query: { refetchInterval: 30_000 },
  })
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold tabular-nums"
      style={{ background: 'rgba(26,128,71,0.1)', color: 'var(--success)' }}
      title="Onchain reputation score"
    >
      <ShieldCheck className="size-3" />
      {data === undefined ? '...' : String(data)}
    </span>
  )
}

function Party({ role, address, me }: { role: string; address: Address; me?: Address }) {
  return (
    <div className="inner flex items-center justify-between gap-2 px-3 py-2.5">
      <div className="min-w-0">
        <div className="label">{role}</div>
        <a
          href={buildAddressExplorerUrl(CHAIN_ID, address)}
          target="_blank"
          rel="noopener noreferrer"
          className="mono text-xs hover:underline"
        >
          {shortAddr(address)}
          {sameAddr(address, me) ? ' (you)' : ''}
        </a>
      </div>
      <ScoreChip address={address} />
    </div>
  )
}

const SAFE_URI = /^(https:\/\/|ipfs:\/\/)/i

function ProofLink({ label, uri }: { label: string; uri: string }) {
  if (!uri) return null
  if (!SAFE_URI.test(uri)) {
    return (
      <p className="text-xs text-pretty" style={{ color: 'var(--muted)' }}>
        <span className="font-semibold">{label}:</span> {uri}
      </p>
    )
  }
  const href = uri.toLowerCase().startsWith('ipfs://') ? `https://ipfs.io/ipfs/${uri.slice(7)}` : uri
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1 text-xs font-semibold"
      style={{ color: 'var(--accent-hover)' }}
    >
      {label} <ExternalLink className="size-3" />
    </a>
  )
}

export function DealCard({ deal: d, me, now }: { deal: Deal; me?: Address; now: number }) {
  const mine = sameAddr(d.seller, me) || sameAddr(d.buyer, me)
  const hasBuyer = d.buyer !== zeroAddress
  const { text: termsText, cid: photoCid } = splitTerms(d.deliveryTerms)
  const lateOpen = d.status === Status.Open && now >= Number(d.deliveryDeadline)

  return (
    <article className="card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="label">Deal #{String(d.id)}</div>
          <h3 className="display mt-0.5 text-xl font-bold text-balance">{d.fabricType}</h3>
          <p className="text-sm tabular-nums" style={{ color: 'var(--muted)' }}>
            {String(d.quantity)} {d.unit}
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          {lateOpen ? <Pill>Expired</Pill> : <StatusPill status={d.status} />}
          <div className="flex items-center gap-1.5">
            <TokenUSDC variant="branded" size={18} />
            <span className="display text-2xl font-bold tabular-nums">{fmtUsdc(d.price)}</span>
          </div>
        </div>
      </div>

      {photoCid && (
        <a
          href={ipfsUrl(photoCid)}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-3 block overflow-hidden rounded-2xl"
          aria-label="Open fabric photo"
        >
          <img
            src={ipfsUrl(photoCid)}
            alt={`${d.fabricType} photo`}
            loading="lazy"
            className="h-48 w-full object-cover"
          />
        </a>
      )}

      <p className="mt-3 text-sm text-pretty" style={{ color: 'var(--ink-2)' }}>
        {termsText || 'No delivery terms provided.'}
      </p>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <Party role="Seller" address={d.seller} me={me} />
        {hasBuyer ? (
          <Party role={d.status === Status.Open ? 'Reserved for' : 'Buyer'} address={d.buyer} me={me} />
        ) : (
          <div className="inner px-3 py-2.5">
            <div className="label">Buyer</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              Open to any buyer
            </div>
          </div>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs" style={{ color: 'var(--muted)' }}>
        <span className="inline-flex items-center gap-1">
          <CalendarClock className="size-3.5" /> Deliver by {fmtDate(d.deliveryDeadline)}
        </span>
        <span>Inspection {String(Number(d.inspectionWindow) / 86_400)}d</span>
        <ProofLink label="Delivery proof" uri={d.deliveryProofURI} />
        <ProofLink label="Inspection note" uri={d.inspectionNoteURI} />
      </div>

      {(mine || d.status === Status.Open || d.status === Status.Disputed || d.status === Status.Delivered) && (
        <div className="mt-4 border-t pt-4" style={{ borderColor: 'var(--border)' }}>
          <DealActions deal={d} me={me} now={now} />
        </div>
      )}
    </article>
  )
}
