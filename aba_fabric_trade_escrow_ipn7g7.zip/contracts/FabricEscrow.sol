// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @title FabricEscrow
/// @notice ERC-20 USDC escrow and public trading reputation for fabric traders.
/// @dev Configure the six-decimal USDC ERC-20 on the target chain at construction.
/// Physical delivery is not verified on-chain: buyers confirm, or the arbiter or owner resolves disputes.
/// No payable entry points, native-currency handling, rescue function, or upgrade mechanism exist.
/// Only the first three completed trades per pair credit reputation; this does not prevent Sybil trading.
contract FabricEscrow is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @notice Deal lifecycle; only Completed deals credit reputation.
    enum Status { Open, Funded, Delivered, Completed, Disputed, Refunded, Cancelled, Split }

    /// @notice All terms and lifecycle data for one deal.
    /// @dev Before funding, buyer is the designated buyer or zero for an open offer.
    /// Price is the total escrow amount, not a per-unit price. All strings are public.
    struct Deal {
        uint256 id;
        address seller;
        address buyer;
        string fabricType;
        uint256 quantity;
        string unit;
        uint256 price;
        string deliveryTerms;
        uint64 deliveryDeadline;
        uint64 inspectionWindow;
        Status status;
        uint64 fundedAt;
        uint64 deliveredAt;
        string deliveryProofURI;
        string inspectionNoteURI;
        uint16 feeBpsSnapshot;
        uint64 disputedAt;
    }

    /// @notice Trading history; volume is raw gross completed USDC volume in base units.
    /// @dev creditedDeals and creditedVolume track pair-capped activity used for the score; raw stats are separate.
    struct Reputation {
        uint32 completedDeals;
        uint32 completedAsSeller;
        uint32 completedAsBuyer;
        uint32 disputesLost;
        uint32 nonDeliveries;
        uint32 uniqueCounterparties;
        uint128 volume;
        uint32 creditedDeals;
        uint128 creditedVolume;
    }

    /// @notice Maximum seller fee, in basis points (2%).
    uint16 public constant MAX_FEE_BPS = 200;
    /// @notice Maximum completed deals per order-independent pair that earn reputation credit.
    uint8 public constant PAIR_CREDIT_CAP = 3;
    /// @notice Minimum offer price: one six-decimal USDC; reputation credit is pair-capped.
    uint256 public constant MIN_REPUTATION_PRICE = 1e6;
    /// @notice Additional time after the delivery deadline before a non-delivery refund.
    uint256 public constant GRACE = 2 days;
    /// @notice Time after a dispute before anyone may split the escrow.
    uint256 public constant DISPUTE_TIMEOUT = 14 days;
    /// @notice Minimum seller-selected inspection duration.
    uint64 public constant MIN_INSPECTION_WINDOW = 1 days;
    /// @notice Maximum seller-selected inspection duration.
    uint64 public constant MAX_INSPECTION_WINDOW = 14 days;
    /// @notice Maximum number of deals returned by getDeals.
    uint256 public constant MAX_PAGE_SIZE = 50;
    /// @notice Immutable six-decimal USDC ERC-20; never the native currency.
    IERC20 public immutable usdc;
    /// @notice Current dispute resolver; initially the constructor's owner.
    address public arbiter;
    /// @notice Fee rate used for newly funded deals; initially zero.
    uint16 public feeBps;
    /// @notice Recipient of USDC fees at settlement; always nonzero.
    address public feeRecipient;

    uint256 private _dealCount;
    mapping(uint256 => Deal) private _deals;
    mapping(address => uint256[]) private _sellerDeals;
    mapping(address => uint256[]) private _buyerDeals;
    mapping(address => Reputation) private _reputations;
    mapping(bytes32 => bool) private _completedPairs;
    mapping(bytes32 => uint8) private _creditedPairDeals;
    /// @notice Deferred USDC payouts, still held by this contract until withdrawn.
    mapping(address => uint256) public claimable;

    /// @notice An address must not be zero.
    error ZeroAddress();
    /// @notice A deal id does not exist.
    error UnknownDeal(uint256 id);
    /// @notice The caller is not authorized for this operation.
    error Unauthorized();
    /// @notice The operation is not allowed in the deal's current state.
    error InvalidStatus(uint256 id, Status actual);
    /// @notice Quantity must be positive.
    error InvalidAmount();
    /// @notice Total price must be at least one six-decimal USDC.
    error PriceTooLow();
    /// @notice The delivery deadline plus grace period has passed.
    error DeliveryWindowClosed();
    /// @notice A seller cannot also be the buyer.
    error SelfDeal();
    /// @notice A string exceeds its byte-length limit.
    error StringTooLong(uint256 actual, uint256 maximum);
    /// @notice The delivery deadline must be strictly in the future.
    error InvalidDeadline();
    /// @notice The inspection duration must be between one and fourteen days.
    error InvalidInspectionWindow();
    /// @notice Funding must occur strictly before the delivery deadline.
    error FundingClosed();
    /// @notice The relevant refund or inspection period has not ended.
    error WaitingPeriodActive();
    /// @notice A delivered deal's inspection period has ended.
    error InspectionWindowClosed();
    /// @notice The escrow must receive exactly the deal price.
    error IncorrectReceivedAmount();
    /// @notice The protocol fee exceeds the hard cap.
    error FeeTooHigh();
    /// @notice Reputation volume cannot be represented without truncation.
    error ReputationVolumeOverflow();
    /// @notice A timestamp cannot be represented in a deal's uint64 field.
    error TimestampOverflow();

    /// @notice A seller created an open offer; buyer may be zero until funding.
    event DealCreated(uint256 indexed id, address indexed seller, address indexed buyer, uint256 price);
    /// @notice An unfunded offer was cancelled by its seller.
    event DealCancelled(uint256 indexed id);
    /// @notice The buyer funded the escrow at the snapshotted fee rate.
    event DealFunded(uint256 indexed id, address indexed buyer, uint256 price, uint16 feeBpsSnapshot);
    /// @notice The seller declared delivery and supplied an optional public proof URI.
    event DealDelivered(uint256 indexed id, string proofURI, uint64 deliveredAt);
    /// @notice Funds were released and the deal completed.
    event DealCompleted(
        uint256 indexed id, address indexed seller, address indexed buyer, uint256 amountToSeller, uint256 fee
    );
    /// @notice The buyer disputed a deal; reasonURI is bounded to 256 bytes.
    event DealDisputed(uint256 indexed id, address indexed buyer, string reasonURI);
    /// @notice The arbiter or owner resolved a dispute in favor of the seller or buyer.
    event DealResolved(uint256 indexed id, address indexed arbiter, bool releaseToSeller);
    /// @notice The buyer received a full refund; nonDelivery distinguishes expiry from arbitration.
    event DealRefunded(uint256 indexed id, address indexed buyer, uint256 amount, bool nonDelivery);
    /// @notice A stale dispute split the escrow without reputation credit or penalties.
    event DealSplit(uint256 indexed id, uint256 amountToSeller, uint256 amountToBuyer, uint256 fee);
    /// @notice A failed payout became a withdrawable credit held by this contract.
    event PayoutDeferred(address indexed to, uint256 amount);
    /// @notice A claimant withdrew their entire deferred balance to the chosen recipient.
    event Withdrawn(address indexed claimant, address indexed to, uint256 amount);
    /// @notice A trader's reputation changed, including penalties.
    event ReputationUpdated(address indexed user, uint256 newScore);
    /// @notice The dispute resolver changed.
    event ArbiterUpdated(address indexed previousArbiter, address indexed newArbiter);
    /// @notice The fee for future funding changed.
    event FeeBpsUpdated(uint16 previousFeeBps, uint16 newFeeBps);
    /// @notice The recipient used for future settlements changed.
    event FeeRecipientUpdated(address indexed previousRecipient, address indexed newRecipient);
    /// @notice A buyer supplied an optional public inspection note when confirming delivery.
    event InspectionNoteRecorded(uint256 indexed id, string inspectionNoteURI);

    /// @notice Initialize the USDC token, owner, arbiter, and fee recipient.
    /// @param usdc_ Nonzero address of the target chain's six-decimal USDC ERC-20.
    /// @param owner_ Nonzero owner, initial arbiter, and initial fee recipient.
    constructor(address usdc_, address owner_) Ownable(owner_) {
        if (usdc_ == address(0) || owner_ == address(0)) revert ZeroAddress();
        usdc = IERC20(usdc_);
        arbiter = owner_;
        feeRecipient = owner_;
        emit ArbiterUpdated(address(0), owner_);
        emit FeeRecipientUpdated(address(0), owner_);
    }

    /// @notice Create an unfunded fabric offer; its id starts at one.
    /// @param fabricType Fabric description, at most 64 bytes.
    /// @param quantity Positive number of units offered.
    /// @param unit Unit description, at most 16 bytes (for example, yards).
    /// @param price Total price in six-decimal USDC base units, at least MIN_REPUTATION_PRICE.
    /// @param deliveryTerms Public delivery terms, at most 512 bytes.
    /// @param deliveryDeadline Future Unix timestamp for delivery.
    /// @param inspectionWindow Seller-selected inspection period, one through fourteen days.
    /// @param designatedBuyer Exclusive buyer, or zero to accept the first eligible funder.
    /// @return dealId The newly allocated id.
    function createDeal(
        string calldata fabricType,
        uint256 quantity,
        string calldata unit,
        uint256 price,
        string calldata deliveryTerms,
        uint64 deliveryDeadline,
        uint64 inspectionWindow,
        address designatedBuyer
    ) external returns (uint256 dealId) {
        _checkLength(fabricType, 64);
        _checkLength(unit, 16);
        _checkLength(deliveryTerms, 512);
        if (quantity == 0) revert InvalidAmount();
        if (price < MIN_REPUTATION_PRICE) revert PriceTooLow();
        if (deliveryDeadline <= block.timestamp) revert InvalidDeadline();
        if (inspectionWindow < MIN_INSPECTION_WINDOW || inspectionWindow > MAX_INSPECTION_WINDOW) {
            revert InvalidInspectionWindow();
        }
        if (designatedBuyer == msg.sender) revert SelfDeal();

        dealId = ++_dealCount;
        Deal storage d = _deals[dealId];
        d.id = dealId;
        d.seller = msg.sender;
        d.buyer = designatedBuyer;
        d.fabricType = fabricType;
        d.quantity = quantity;
        d.unit = unit;
        d.price = price;
        d.deliveryTerms = deliveryTerms;
        d.deliveryDeadline = deliveryDeadline;
        d.inspectionWindow = inspectionWindow;
        d.status = Status.Open;
        _sellerDeals[msg.sender].push(dealId);
        emit DealCreated(dealId, msg.sender, designatedBuyer, price);
    }

    /// @notice Cancel an Open offer; only its seller may call.
    function cancelDeal(uint256 id) external {
        Deal storage d = _getDeal(id);
        if (msg.sender != d.seller) revert Unauthorized();
        _requireStatus(d, Status.Open);
        d.status = Status.Cancelled;
        emit DealCancelled(id);
    }

    /// @notice Fund an Open deal before its deadline using a prior ERC-20 approval.
    /// @dev Rejects seller funding, unauthorized buyers, and non-exact incoming token transfers.
    function fundDeal(uint256 id) external nonReentrant {
        Deal storage d = _getDeal(id);
        _requireStatus(d, Status.Open);
        if (msg.sender == d.seller) revert SelfDeal();
        if (d.buyer != address(0) && msg.sender != d.buyer) revert Unauthorized();
        if (block.timestamp >= d.deliveryDeadline) revert FundingClosed();
        d.buyer = msg.sender;
        d.fundedAt = _timestamp();
        d.feeBpsSnapshot = feeBps;
        d.status = Status.Funded;
        _buyerDeals[msg.sender].push(id);

        uint256 beforeBalance = usdc.balanceOf(address(this));
        usdc.safeTransferFrom(msg.sender, address(this), d.price);
        uint256 afterBalance = usdc.balanceOf(address(this));
        if (afterBalance < beforeBalance || afterBalance - beforeBalance != d.price) {
            revert IncorrectReceivedAmount();
        }
        emit DealFunded(id, msg.sender, d.price, d.feeBpsSnapshot);
    }

    /// @notice Seller declares delivery of a Funded deal, starting its inspection window.
    /// @dev The optional proof URI is public and limited to 256 bytes; no oracle validates it.
    function markDelivered(uint256 id, string calldata proofURI) external {
        Deal storage d = _getDeal(id);
        if (msg.sender != d.seller) revert Unauthorized();
        _requireStatus(d, Status.Funded);
        if (block.timestamp > uint256(d.deliveryDeadline) + GRACE) revert DeliveryWindowClosed();
        _checkLength(proofURI, 256);
        d.deliveryProofURI = proofURI;
        d.deliveredAt = _timestamp();
        d.status = Status.Delivered;
        emit DealDelivered(id, proofURI, d.deliveredAt);
    }

    /// @notice Buyer accepts delivery of a Funded or Delivered deal and releases USDC.
    /// @dev The optional inspection URI is public and limited to 256 bytes.
    function confirmDelivery(uint256 id, string calldata inspectionNoteURI) external nonReentrant {
        Deal storage d = _getDeal(id);
        if (msg.sender != d.buyer) revert Unauthorized();
        _requireActive(d);
        _checkLength(inspectionNoteURI, 256);
        d.inspectionNoteURI = inspectionNoteURI;
        emit InspectionNoteRecorded(id, inspectionNoteURI);
        _complete(d);
    }

    /// @notice Anyone may release a Delivered deal strictly after its inspection window.
    /// @dev Disputed deals cannot be released through this path.
    function claimAfterInspectionWindow(uint256 id) external nonReentrant {
        Deal storage d = _getDeal(id);
        _requireStatus(d, Status.Delivered);
        if (block.timestamp <= uint256(d.deliveredAt) + d.inspectionWindow) revert WaitingPeriodActive();
        _complete(d);
    }

    /// @notice Anyone may refund the recorded buyer after deadline plus the fixed two-day grace.
    /// @dev Only Funded deals qualify; seller non-delivery receives a penalty at any price.
    function refundExpired(uint256 id) external nonReentrant {
        Deal storage d = _getDeal(id);
        _requireStatus(d, Status.Funded);
        if (block.timestamp <= uint256(d.deliveryDeadline) + GRACE) revert WaitingPeriodActive();
        d.status = Status.Refunded;
        _reputations[d.seller].nonDeliveries++;
        emit ReputationUpdated(d.seller, scoreOf(d.seller));
        emit DealRefunded(id, d.buyer, d.price, true);
        _payOut(d.buyer, d.price);
    }

    /// @notice Buyer disputes a Funded deal, or a Delivered deal through the inspection boundary.
    /// @dev The public reason URI is limited to 256 bytes. At the exact boundary disputes still win.
    function raiseDispute(uint256 id, string calldata reasonURI) external {
        Deal storage d = _getDeal(id);
        if (msg.sender != d.buyer) revert Unauthorized();
        _requireActive(d);
        if (d.status == Status.Delivered && block.timestamp > uint256(d.deliveredAt) + d.inspectionWindow) {
            revert InspectionWindowClosed();
        }
        _checkLength(reasonURI, 256);
        d.status = Status.Disputed;
        d.disputedAt = _timestamp();
        emit DealDisputed(id, msg.sender, reasonURI);
    }

    /// @notice The arbiter or owner may resolve a Disputed deal, releasing or refunding the full escrow.
    /// @dev Release deducts the snapshotted fee and applies pair-capped credit to both parties; refund penalizes only seller.
    function resolveDispute(uint256 id, bool releaseToSeller) external nonReentrant {
        if (msg.sender != arbiter && msg.sender != owner()) revert Unauthorized();
        Deal storage d = _getDeal(id);
        _requireStatus(d, Status.Disputed);
        emit DealResolved(id, msg.sender, releaseToSeller);
        if (releaseToSeller) {
            _complete(d);
        } else {
            d.status = Status.Refunded;
            _reputations[d.seller].disputesLost++;
            emit ReputationUpdated(d.seller, scoreOf(d.seller));
            emit DealRefunded(id, d.buyer, d.price, false);
            _payOut(d.buyer, d.price);
        }
    }

    /// @notice Anyone may split a dispute strictly after fourteen days without reputation changes.
    /// @dev Seller receives half less its snapshotted fee; buyer receives any division remainder.
    /// This deliberate neutral, last-resort liveness fallback gives no reputation credit or penalty.
    /// Deployments should set arbiter and owner to different parties so either can resolve disputes first.
    function resolveStaleDispute(uint256 id) external nonReentrant {
        Deal storage d = _getDeal(id);
        _requireStatus(d, Status.Disputed);
        if (block.timestamp <= uint256(d.disputedAt) + DISPUTE_TIMEOUT) revert WaitingPeriodActive();
        uint256 sellerHalf = d.price / 2;
        uint256 rate = d.feeBpsSnapshot;
        uint256 fee = (sellerHalf / 10_000) * rate + ((sellerHalf % 10_000) * rate) / 10_000;
        uint256 amountToSeller = sellerHalf - fee;
        uint256 amountToBuyer = d.price - sellerHalf;
        address recipient = feeRecipient;
        d.status = Status.Split;
        emit DealSplit(id, amountToSeller, amountToBuyer, fee);
        _payOut(d.seller, amountToSeller);
        _payOut(d.buyer, amountToBuyer);
        if (fee != 0) _payOut(recipient, fee);
    }

    /// @notice Withdraw the caller's entire deferred USDC balance to a nonzero recipient.
    /// @dev A failed withdrawal reverts, restoring the caller's credit for another attempt.
    function withdraw(address to) external nonReentrant {
        if (to == address(0)) revert ZeroAddress();
        uint256 amount = claimable[msg.sender];
        claimable[msg.sender] = 0;
        usdc.safeTransfer(to, amount);
        emit Withdrawn(msg.sender, to, amount);
    }

    /// @notice Owner changes the nonzero arbiter, including for existing disputes.
    function setArbiter(address newArbiter) external onlyOwner {
        if (newArbiter == address(0)) revert ZeroAddress();
        emit ArbiterUpdated(arbiter, newArbiter);
        arbiter = newArbiter;
    }

    /// @notice Owner sets the fee for future funding, capped at 200 basis points.
    /// @dev Previously funded deals retain their snapshotted rate.
    function setFeeBps(uint16 newFeeBps) external onlyOwner {
        if (newFeeBps > MAX_FEE_BPS) revert FeeTooHigh();
        emit FeeBpsUpdated(feeBps, newFeeBps);
        feeBps = newFeeBps;
    }

    /// @notice Owner sets the nonzero recipient for fees on subsequent settlements.
    /// @dev Nonzero is required even at a zero current rate because existing deals may owe fees.
    function setFeeRecipient(address newFeeRecipient) external onlyOwner {
        if (newFeeRecipient == address(0)) revert ZeroAddress();
        emit FeeRecipientUpdated(feeRecipient, newFeeRecipient);
        feeRecipient = newFeeRecipient;
    }

    /// @notice Return the full terms and lifecycle data for an existing deal.
    function getDeal(uint256 id) external view returns (Deal memory) {
        return _getDeal(id);
    }

    /// @notice Return the total number of deals ever created, including cancelled ones.
    function dealCount() external view returns (uint256) {
        return _dealCount;
    }

    /// @notice Return all ids created by a seller; this unbounded convenience view is intended for off-chain use.
    function getDealsBySeller(address seller) external view returns (uint256[] memory) {
        return _sellerDeals[seller];
    }

    /// @notice Return all ids actually funded by a buyer, not unfunded designated offers.
    /// @dev This unbounded convenience view is intended for off-chain use; use getDeals for bounded listing.
    function getDealsByBuyer(address buyer) external view returns (uint256[] memory) {
        return _buyerDeals[buyer];
    }

    /// @notice Return a page of deals in ascending id order, capped to 50 items.
    /// @param offset Zero-based number of deals to skip; offset zero starts at deal id one.
    /// @param limit Requested page length, clamped to MAX_PAGE_SIZE.
    /// @return page Empty when offset is past the last deal or limit is zero.
    function getDeals(uint256 offset, uint256 limit) external view returns (Deal[] memory page) {
        if (limit > MAX_PAGE_SIZE) limit = MAX_PAGE_SIZE;
        if (offset >= _dealCount) return new Deal[](0);
        uint256 remaining = _dealCount - offset;
        if (limit > remaining) limit = remaining;
        page = new Deal[](limit);
        for (uint256 i = 0; i < limit; ++i) {
            page[i] = _deals[offset + i + 1];
        }
    }

    /// @notice Return a trader's raw and credited reputation stats separately from its current computed score.
    function reputationOf(address user) external view returns (Reputation memory r, uint256 score) {
        r = _reputations[user];
        score = scoreOf(user);
    }

    /// @notice Compute the public nonnegative trading score from credited activity and penalties, not raw totals.
    /// @dev Score = creditedDeals*10 + uniqueCounterparties*15 + min(creditedVolume/100e6,200)
    /// minus disputesLost*40 and nonDeliveries*40, floored at zero. All arithmetic uses uint256.
    /// Only the first PAIR_CREDIT_CAP completions per pair earn credit; raw stats are shown separately.
    function scoreOf(address user) public view returns (uint256) {
        Reputation storage r = _reputations[user];
        uint256 volumePoints = uint256(r.creditedVolume) / 100e6;
        if (volumePoints > 200) volumePoints = 200;
        uint256 positive = uint256(r.creditedDeals) * 10 + uint256(r.uniqueCounterparties) * 15 + volumePoints;
        uint256 negative = uint256(r.disputesLost) * 40 + uint256(r.nonDeliveries) * 40;
        return positive > negative ? positive - negative : 0;
    }

    function _getDeal(uint256 id) private view returns (Deal storage d) {
        d = _deals[id];
        if (d.id == 0) revert UnknownDeal(id);
    }

    function _requireStatus(Deal storage d, Status expected) private view {
        if (d.status != expected) revert InvalidStatus(d.id, d.status);
    }

    function _requireActive(Deal storage d) private view {
        if (d.status != Status.Funded && d.status != Status.Delivered) revert InvalidStatus(d.id, d.status);
    }

    function _checkLength(string calldata value, uint256 maximum) private pure {
        if (bytes(value).length > maximum) revert StringTooLong(bytes(value).length, maximum);
    }

    function _timestamp() private view returns (uint64) {
        if (block.timestamp > type(uint64).max) revert TimestampOverflow();
        return uint64(block.timestamp);
    }

    /// @dev Failed transfers leave the USDC in escrow and record a withdrawable liability.
    function _payOut(address to, uint256 amount) internal {
        if (amount == 0) return;
        (bool success, bytes memory result) = address(usdc).call(abi.encodeCall(IERC20.transfer, (to, amount)));
        bool transferred = success && (
            result.length == 0
                ? address(usdc).code.length != 0
                : result.length >= 32 && abi.decode(result, (uint256)) == 1
        );
        if (!transferred) {
            claimable[to] += amount;
            emit PayoutDeferred(to, amount);
        }
    }

    // All callers are nonReentrant and validate their respective release conditions.
    // The quotient/remainder calculation is floor(price*bps/10000) without multiplication overflow.
    function _complete(Deal storage d) private {
        d.status = Status.Completed;
        uint256 rate = d.feeBpsSnapshot;
        uint256 fee = (d.price / 10_000) * rate + ((d.price % 10_000) * rate) / 10_000;
        uint256 amountToSeller = d.price - fee;
        address recipient = feeRecipient;
        _creditReputation(d);
        emit DealCompleted(d.id, d.seller, d.buyer, amountToSeller, fee);
        _payOut(d.seller, amountToSeller);
        if (fee != 0) _payOut(recipient, fee);
    }

    function _creditReputation(Deal storage d) private {
        Reputation storage sellerRep = _reputations[d.seller];
        Reputation storage buyerRep = _reputations[d.buyer];
        _creditCompleted(sellerRep, d.price);
        _creditCompleted(buyerRep, d.price);
        sellerRep.completedAsSeller++;
        buyerRep.completedAsBuyer++;

        bytes32 pair = d.seller < d.buyer
            ? keccak256(abi.encode(d.seller, d.buyer))
            : keccak256(abi.encode(d.buyer, d.seller));
        if (_creditedPairDeals[pair] < PAIR_CREDIT_CAP) {
            _creditedPairDeals[pair]++;
            sellerRep.creditedDeals++;
            buyerRep.creditedDeals++;
            // Raw volume was checked above; credited volume is a subset of that total.
            sellerRep.creditedVolume += uint128(d.price);
            buyerRep.creditedVolume += uint128(d.price);
        }
        if (!_completedPairs[pair]) {
            _completedPairs[pair] = true;
            sellerRep.uniqueCounterparties++;
            buyerRep.uniqueCounterparties++;
        }
        emit ReputationUpdated(d.seller, scoreOf(d.seller));
        emit ReputationUpdated(d.buyer, scoreOf(d.buyer));
    }

    function _creditCompleted(Reputation storage r, uint256 price) private {
        // Check before narrowing: never silently truncate the public uint128 volume.
        if (price > uint256(type(uint128).max) - uint256(r.volume)) revert ReputationVolumeOverflow();
        r.completedDeals++;
        r.volume += uint128(price);
    }
}
